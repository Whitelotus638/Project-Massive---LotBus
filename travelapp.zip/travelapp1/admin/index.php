
<?php
require "../koneksi.php";
require "template/head.php";
require "template/navbar.php";
require "content.php";
require "template/footer.php";

?>