<!-- Page Sidebar Ends-->
<div class="page-body">
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-sm-6">
                    <h3>Form Tambah Data Driver</h3>

                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-xl-6">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-header pb-0">

                            </div>
                            <div class="card-body">
                                <form class="theme-form" action="pages/simpandriver.php" method="post">
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Usename</label>
                                        <input class="form-control" name="username" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="masukkan Username"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Nama</label>
                                        <input class="form-control" name="nama" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="Nama "><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">NIK</label>
                                        <input class="form-control" name="nik" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="NIK"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Tempat Lahir</label>
                                        <input class="form-control" name="tmplahir" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="Tempat Lahir"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Tanggal lahir</label>
                                        <input class="form-control" name="tgllahir" id="exampleInputEmail1" type="date" aria-describedby="emailHelp" placeholder="Tanggal Lahir"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Jenis Kelamin</label>
                                        <input class="form-control" name="jkel" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="Jenis Kelamin"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Alamat</label>
                                        <input class="form-control" name="alamat" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="Alamat"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Usia</label>
                                        <input class="form-control" name="usia" id="exampleInputEmail1" type="number" aria-describedby="emailHelp" placeholder="Usia"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="col-form-label pt-0" for="exampleInputEmail1">Email</label>
                                        <input class="form-control" name="email" id="exampleInputEmail1" type="text" aria-describedby="emailHelp" placeholder="Email"><small class="form-text text-muted" id="emailHelp"></small>
                                    </div>
                                    <div class="card-footer">
                                <button class="btn btn-primary">Simpan</button>
                                <button class="btn btn-secondary">Cancel</button>
                            </div>

                                </form>
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- Container-fluid Ends-->
</div>