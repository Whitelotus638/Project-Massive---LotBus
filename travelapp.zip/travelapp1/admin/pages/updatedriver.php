<?php 
require "../../Koneksi.php";
$id           	    =$_POST['username']; 
$nm           	    =$_POST['nama']; 
$nik				=$_POST['nik'];
$tmplahir			=$_POST['tmplahir'];
$tgllahir			=$_POST['tgllahir'];
$alamat			    =$_POST['alamat'];
$jkel				=$_POST['jkel'];
$usia				=$_POST['usia'];
$email				=$_POST['email'];
 

$qr_update	="UPDATE tbdriver SET nama='$nm', nik='$nik', tmplahir='$tmplahir', tgllahir='$tgllahir', alamat='$alamat', jkel='$jkel', usia='$usia', email='$email'  WHERE username ='$id'";
$res_update = mysqli_query($connected, $qr_update);

if(!$res_update){
	?>	
	<script type="text/javascript">
		alert ('Data gagal diupdate...');
	location.href='../index.php?p=ddriver';
	</script>
	<?php
} else {
	?>
	<script type="text/javascript">
		alert('Data berhasil diupdate...');
		location.href='../index.php?p=ddriver';
	</script>
	<?php
}
?>